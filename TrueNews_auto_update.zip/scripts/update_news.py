#!/usr/bin/env python3
import json, re, html, hashlib
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET

SOURCES = [
    ("РБК", "https://news.google.com/rss/search?q=site%3Arbc.ru%20when%3A1d&hl=ru&gl=RU&ceid=RU%3Aru"),
    ("Фонтанка", "https://news.google.com/rss/search?q=site%3Afontanka.ru%20when%3A1d&hl=ru&gl=RU&ceid=RU%3Aru"),
    ("RT", "https://news.google.com/rss/search?q=site%3Art.com%20Russia%20when%3A1d&hl=ru&gl=RU&ceid=RU%3Aru"),
    ("ТАСС", "https://news.google.com/rss/search?q=site%3Atass.ru%20when%3A1d&hl=ru&gl=RU&ceid=RU%3Aru"),
]
OUT = Path("news.json")

def clean(s):
    s = html.unescape(re.sub(r"<[^>]+>", " ", s or ""))
    return re.sub(r"\s+", " ", s).strip()

def category(title):
    t = title.lower()
    if any(w in t for w in ["футбол","хоккей","теннис","матч","турнир","спорт","ufc","бокс","бойцов"]):
        return "Спорт"
    if any(w in t for w in ["президент","правитель","государ","парламент","министр","мид","выбор","политик","санкц","переговор"]):
        return "Политика"
    return "Главное"

def parse_date(s):
    try:
        from email.utils import parsedate_to_datetime
        return parsedate_to_datetime(s).isoformat()
    except Exception:
        return datetime.now(timezone.utc).isoformat()

def fetch(name, url):
    req=Request(url,headers={"User-Agent":"TrueNews/1.0 RSS reader"})
    data=urlopen(req,timeout=20).read()
    root=ET.fromstring(data)
    items=[]
    for it in root.findall(".//item")[:12]:
        title=clean(it.findtext("title"))
        link=it.findtext("link") or ""
        desc=clean(it.findtext("description"))
        pub=parse_date(it.findtext("pubDate") or "")
        if not title: continue
        items.append({"title":title,"link":link,"description":desc,"pub":pub,"source":name,"category":category(title)})
    return items

def make_article(x):
    desc=x["description"] or "Редакция TrueNews продолжает собирать подтверждённую информацию по событию."
    title=x["title"]
    return (
        f"<h3>Что произошло</h3><p>{html.escape(desc)}</p>"
        f"<h3>Контекст</h3><p>Новость рассматривается в контексте текущей повестки. "
        f"Редакция TrueNews отделяет подтверждённые сведения от предположений и следит за новыми заявлениями участников события.</p>"
        f"<h3>Почему это важно</h3><p>Развитие ситуации может повлиять на людей, экономику, политику или дальнейшие решения сторон. "
        f"Ключевые изменения будут добавляться в материал по мере появления новых данных.</p>"
        f"<h3>Что известно сейчас</h3><p>{html.escape(desc)} "
        f"Дополнительные детали проверяются редакцией перед публикацией.</p>"
        f"<h3>Что дальше</h3><p>TrueNews продолжит следить за развитием события и обновлять материал, "
        f"если появятся новые официальные сообщения или существенные изменения.</p>"
        f"<p><small>Материал подготовлен редакцией TrueNews на основе доступной новостной информации.</small></p>"
    )

all_items=[]
for name,url in SOURCES:
    try: all_items.extend(fetch(name,url))
    except Exception as e: print("RSS error",name,e)

seen=set(); result=[]
for x in sorted(all_items,key=lambda z:z["pub"],reverse=True):
    key=hashlib.sha1((x["title"].lower()+"|"+x["link"]).encode()).hexdigest()
    if key in seen: continue
    seen.add(key)
    x["id"]=key
    x["summary"]=x["description"][:220] + ("…" if len(x["description"])>220 else "")
    x["article"]=make_article(x)
    result.append(x)
result=result[:30]
OUT.write_text(json.dumps({"updated":datetime.now(timezone.utc).isoformat(),"items":result},ensure_ascii=False,indent=2),encoding="utf-8")
print("Saved",len(result),"news")
