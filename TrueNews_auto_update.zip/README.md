# TrueNews — автообновление

- RSS обновляется GitHub Actions каждые 30 минут.
- Источники: поисковые RSS-ленты Google News по выбранным изданиям.
- Новые материалы сохраняются в `news.json`.
- GitHub Pages показывает `news.json` без стороннего API.
- Ручной запуск: Actions → Update TrueNews news → Run workflow.

Важно: после загрузки файлов включи GitHub Pages из ветки `main` (root), если он ещё не включён.
